# AI Amigos Remediation WordPress plugin

This is a reversible, front-end-only remediation layer for the deployed AIAmigos WordPress site. It does **not** rewrite posts, fabricate author identities, delete factual content, edit theme files, buffer whole HTML documents, create database tables, or call external services.

## Install and activate

1. Copy the complete `aiamigos-remediation` directory to `wp-content/plugins/`.
2. Before activation, configure WordPress with the intended static front page at `/` and the native posts page at `/blog/`. The plugin deliberately does not rewrite those database options.
3. Back up the site and activate **AI Amigos Remediation** in a staging environment first.
4. Purge LiteSpeed/page/CDN caches.
5. Verify the acceptance checklist below before production activation.

Production `aiamigos.org` links are normalized to `https://www.aiamigos.org/`. On any non-production hostname, the plugin keeps that host and forces HTTPS. `aiamigos_remediation_canonical_base_url` can explicitly override this behavior.

## What it changes at runtime

- Permanent, GET/HEAD-only front-end redirects:
  - `/home/` → `/`
  - `/page/N/` for `N >= 2` → `/blog/page/N/`
  - `/newsletter-2/` → `/newsletter/`
- Rank Math/Yoast canonical and differentiated-title filters for the already configured native `/blog/` posts page and its pagination. The plugin does not create or replace the native route.
- Exact `410 Gone` for the eight known theme-demo records:
  - two `classes/recent-case-title-*` records;
  - three `testimonials/client-name-*` records;
  - `team/member-name-02` through `member-name-04`.
- Quarantines the same exact seeded record IDs (`34, 36, 46, 48, 50, 40, 42, 44`) from every non-admin front-end query, Rank Math XML sitemap entry, WordPress core post sitemap query, and Yoast sitemap exclusion list. Existing exclusions and explicit `post__in` allowlists are handled fail-closed. The genuine Vijay team record ID `38` is explicitly not quarantined, and all underlying records remain recoverable in the admin.
- Excludes factual-risk IDs `945, 441, 783, 1405` from XML sitemaps whenever they are published with the temporary noindex policy, preventing an index/noindex contradiction.
- `noindex,follow` for four filterable high-risk factual routes (`ai-certifications`, `gpt-models`, `grokai`, and the model-benchmark article) and archive/search surfaces. Content remains available and untouched. The canonical `/blog/` archive is excluded.
- Same-site nav-menu href normalization from HTTP, apex-host, and `/index.php/` URLs to the final HTTPS origin/path. External URLs are unchanged.
- Removes `async`/`defer` **only** from script tags whose exact handles are `wp-hooks` or `wp-i18n`; other scripts retain their loading strategy.
- Adds conservative public-response headers: six-month HSTS on HTTPS (no preload or subdomain assertion), `nosniff`, `SAMEORIGIN` frame protection, strict-origin referrer policy, a deny-by-default policy for camera, microphone, geolocation, payment, and USB, and a five-minute anonymous HTML cache policy. It also asks PHP to remove the `X-Powered-By` disclosure.
- Removes WordPress generator output.
- Replaces MailPoet form IDs 2/3 in widget/page content with the single published Contact Form 7 form whose exact title is `Subscribe Newsletter Form`. Empty, missing, duplicate, non-published, or ambiguous matches fail closed to an honest `mailto:contact@aiamigos.org` request link. The replacement is explicitly labelled an **update request**, not an automatic newsletter subscription.
- Corrects the VW Sirat Pro theme-mod compatibility defect without changing saved Customizer data:
  - suppresses an email-like `vw_sirat_pro_header_section_call2` value so it is not emitted as `tel:`;
  - uses that valid email in `vw_sirat_pro_header_section_email` only when the dedicated email field is empty;
  - preserves genuine phone values.
- Filters the footer to a dynamic `© YEAR AI Amigos.` notice and hides the VW Themes credit link. Saved theme mods are not changed.
- Injects a cautious, escaped front-page introduction through `vw_sirat_pro_after_section_slider`:
  - H1: `AI Amigos: practical artificial intelligence guides`
  - explanatory text reminding readers to check dates and sources.
- Injects one escaped `AI Amigos Blog` H1 at `loop_start` for the main `is_home()` posts loop, including paginated `/blog/` pages.
- Prepends a visible, escaped byline to the main content of standard single posts, using the stored author display name, published date, and an updated date only when it differs by at least 24 hours. It does not claim independent review.
- Normalizes Sirat widget title wrappers from H3 to H2 on the public front end, while the update-request section uses its own accessible label.
- Requests the registered `large` featured-image size on archive/listing loops. WordPress core retains control of `loading`, `decoding`, and `fetchpriority`, avoiding an LCP regression. The plugin does not create missing image derivatives; regenerate thumbnails separately if required.

Admin, AJAX, REST, XML-RPC, cron, and WP-CLI requests are excluded from redirects and presentation filters.

## Acceptance checklist

After activation and cache purge, verify:

1. `/` is the intended home content and contains exactly one visible cautious H1.
2. `/home/` returns one permanent redirect to `/`.
3. `/blog/` and `/blog/page/2/` return unique `200` archives, self-canonicalize, expose one `AI Amigos Blog` H1, and together paginate the post inventory.
4. `/page/2/` returns one permanent redirect to `/blog/page/2/`.
5. `/newsletter-2/` redirects to `/newsletter/`; update-request forms submit to the intended CF7 workflow and do not promise subscription.
6. All eight exact placeholder routes return `410`; IDs `34, 36, 46, 48, 50, 40, 42, 44` are absent from public listings/search/sitemaps; team ID `38` and `/team/member-name-01/` remain available.
7. High-risk pages remain readable but emit `noindex,follow`; `/blog/` remains indexable.
8. Menus contain no apex, HTTP, or `/index.php/` internal hrefs.
9. Browser console no longer reports `wp is not defined` and only `wp-hooks`/`wp-i18n` lost loading-strategy attributes.
10. The top bar renders the email as an email link, not `tel:contact@aiamigos.org`; genuine phone data remains.
11. Footer year is current and the misleading theme-credit link is absent.
12. Single posts expose an accountable author/published line, and an updated date only where warranted.
13. Archive image requests resolve to generated `large`/responsive files; the first visible image retains WordPress core's LCP loading/fetch-priority decision.

Run the separate read-only regression harness in `remediation/tests/` for crawl-wide evidence.

## Rollback and uninstall

Deactivate the plugin and purge caches. Deactivation immediately removes all filters/actions: redirects, 410s, query/sitemap quarantine, noindex, headers, menu normalization, shortcode replacement, H1s, image policy, phone/email compatibility, and footer changes disappear. The original routes, saved posts, and theme mods were never modified.

Deletion is safe: `uninstall.php` is intentionally a no-op because the plugin stores no options, posts, metadata, users, tables, or secrets.

## Filters

Route/policy controls are deliberately filterable:

- `aiamigos_remediation_canonical_base_url`
- `aiamigos_remediation_blog_base_path`
- `aiamigos_remediation_redirect_paths`
- `aiamigos_remediation_redirect_status`
- `aiamigos_remediation_preserve_redirect_query`
- `aiamigos_remediation_gone_paths`
- `aiamigos_remediation_quarantined_post_ids`
- `aiamigos_remediation_high_risk_post_ids`
- `aiamigos_remediation_high_risk_noindex_paths`
- `aiamigos_remediation_noindex_archive_surfaces`
- `aiamigos_remediation_should_noindex`
- `aiamigos_remediation_security_headers`
- `aiamigos_remediation_blocking_wp_dependency_handles`
- `aiamigos_remediation_mailpoet_form_ids`
- `aiamigos_remediation_cf7_form_title`
- `aiamigos_remediation_contact_email`
- `aiamigos_remediation_footer_copy`
- `aiamigos_remediation_listing_thumbnail_size`

The blog-base filter changes policy recognition only; native WordPress routing must already serve the selected posts-page path.

## Tests

The pure policy suite has no WordPress dependency:

```sh
php tests/test-policy.php
```

The zero-dependency static package checks run anywhere Node is available:

```sh
node tests/static-check.mjs
```

Lint every PHP file before packaging:

```sh
find . -name '*.php' -exec php -l {} \;
```

This workspace did not provide a PHP executable, so the included test suite and lint commands must be run in staging/CI before activation.
