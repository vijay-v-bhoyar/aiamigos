<?php
/**
 * WordPress integration for the reversible AI Amigos remediation layer.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AIAmigos_Remediation_Plugin', false ) ) {
	final class AIAmigos_Remediation_Plugin {
		/** @var bool */
		private static $booted = false;

		/** @var bool */
		private static $front_intro_rendered = false;

		/** @var bool */
		private static $blog_heading_rendered = false;

		/** @var array<int,bool> */
		private static $byline_rendered = array();

		/**
		 * Register hooks once.
		 *
		 * @return void
		 */
		public static function boot() {
			if ( self::$booted ) {
				return;
			}
			self::$booted = true;

			add_filter( 'document_title_parts', array( __CLASS__, 'filter_blog_document_title' ) );
			add_filter( 'rank_math/frontend/title', array( __CLASS__, 'filter_blog_seo_title' ) );
			add_filter( 'wpseo_title', array( __CLASS__, 'filter_blog_seo_title' ) );
			add_filter( 'rank_math/frontend/canonical', array( __CLASS__, 'filter_blog_canonical' ) );
			add_filter( 'wpseo_canonical', array( __CLASS__, 'filter_blog_canonical' ) );

			add_action( 'template_redirect', array( __CLASS__, 'apply_route_policy' ), 0 );
			add_filter( 'allowed_redirect_hosts', array( __CLASS__, 'allow_canonical_redirect_host' ) );
			add_action( 'pre_get_posts', array( __CLASS__, 'exclude_quarantined_records_from_queries' ), 99 );
			add_filter( 'rank_math/sitemap/entry', array( __CLASS__, 'filter_rank_math_sitemap_entry' ), 99, 3 );
			add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'filter_core_sitemap_query_args' ), 99, 2 );
			add_filter( 'wpseo_exclude_from_sitemap_by_post_ids', array( __CLASS__, 'filter_yoast_sitemap_post_ids' ), 99 );

			add_filter( 'wp_robots', array( __CLASS__, 'filter_wp_robots' ), 99 );
			add_filter( 'rank_math/frontend/robots', array( __CLASS__, 'filter_rank_math_robots' ), 99 );
			add_filter( 'wpseo_robots', array( __CLASS__, 'filter_robots_string' ), 99 );
			add_filter( 'wp_headers', array( __CLASS__, 'filter_response_headers' ), 99 );
			add_action( 'send_headers', array( __CLASS__, 'remove_runtime_disclosure_header' ), 99 );

			add_filter( 'nav_menu_link_attributes', array( __CLASS__, 'normalize_menu_link' ), 99, 4 );
			add_filter( 'script_loader_tag', array( __CLASS__, 'make_wp_dependencies_blocking' ), 99, 3 );

			remove_action( 'wp_head', 'wp_generator' );
			add_filter( 'the_generator', '__return_empty_string', 99 );

			// Run before core do_shortcode (priority 11) so MailPoet never sees the
			// malformed token and the CF7 replacement owns the request path.
			add_filter( 'widget_text', array( __CLASS__, 'replace_mailpoet_form' ), 8 );
			add_filter( 'widget_text_content', array( __CLASS__, 'replace_mailpoet_form' ), 8 );
			add_filter( 'the_content', array( __CLASS__, 'replace_mailpoet_form' ), 8 );
			add_filter( 'the_content', array( __CLASS__, 'prepend_accountable_byline' ), 9 );
			add_filter( 'widget_title', array( __CLASS__, 'label_update_request_widget' ), 20, 3 );
			add_filter( 'dynamic_sidebar_params', array( __CLASS__, 'normalize_widget_heading_level' ), 99 );

			add_filter( 'theme_mod_vw_sirat_pro_header_section_call2', array( __CLASS__, 'filter_theme_phone_mod' ) );
			add_filter( 'theme_mod_vw_sirat_pro_header_section_email', array( __CLASS__, 'filter_theme_email_mod' ) );
			add_filter( 'theme_mod_vw_sirat_pro_footer_copy', array( __CLASS__, 'filter_footer_copy_mod' ) );
			add_filter( 'theme_mod_vw_sirat_pro_hide_show_credit_link', array( __CLASS__, 'hide_theme_credit_mod' ) );

			add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_inline_styles' ), 99 );
			add_action( 'vw_sirat_pro_after_section_slider', array( __CLASS__, 'render_front_page_intro' ), 10 );
			add_action( 'loop_start', array( __CLASS__, 'render_blog_archive_heading' ), 1 );

			add_filter( 'post_thumbnail_size', array( __CLASS__, 'filter_listing_thumbnail_size' ), 99, 2 );
		}

		/**
		 * Flush route and supported sitemap caches after a controlled activation.
		 *
		 * @return void
		 */
		public static function activate() {
			flush_rewrite_rules( false );
			if ( class_exists( '\\RankMath\\Sitemap\\Cache' ) && is_callable( array( '\\RankMath\\Sitemap\\Cache', 'invalidate_storage' ) ) ) {
				\RankMath\Sitemap\Cache::invalidate_storage();
			}
			if ( class_exists( 'WPSEO_Sitemaps_Cache' ) && is_callable( array( 'WPSEO_Sitemaps_Cache', 'clear' ) ) ) {
				WPSEO_Sitemaps_Cache::clear();
			}
		}

		/**
		 * Whether this is a public front-end request suitable for mutations.
		 *
		 * @return bool
		 */
		private static function is_frontend_request() {
			if ( is_admin() ) {
				return false;
			}
			if ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) {
				return false;
			}
			if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
				return false;
			}
			if ( defined( 'WP_CLI' ) && WP_CLI ) {
				return false;
			}
			if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
				return false;
			}
			if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
				return false;
			}

			$request_path = AIAmigos_Remediation_Policy::normalize_path( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/' );
			if ( 0 === strpos( $request_path, '/wp-json/' ) ) {
				return false;
			}

			return true;
		}

		/**
		 * Canonical base URL. Production is forced to www/HTTPS while non-production
		 * hosts remain on their own HTTPS origin unless explicitly filtered.
		 *
		 * @return string
		 */
		private static function canonical_base_url() {
			$home = home_url( '/' );
			$host = wp_parse_url( $home, PHP_URL_HOST );
			if ( $host && 'aiamigos.org' === strtolower( preg_replace( '/^www\./i', '', $host ) ) ) {
				$default = 'https://www.aiamigos.org/';
			} else {
				$default = set_url_scheme( $home, 'https' );
			}
			$base = apply_filters( 'aiamigos_remediation_canonical_base_url', $default );
			$base = esc_url_raw( (string) $base );
			return $base ? trailingslashit( $base ) : trailingslashit( $default );
		}

		/**
		 * Filterable canonical blog base path.
		 *
		 * @return string
		 */
		private static function blog_base_path() {
			$base = (string) apply_filters( 'aiamigos_remediation_blog_base_path', '/blog/' );
			return AIAmigos_Remediation_Policy::normalize_path( $base );
		}

		/**
		 * Exact canonical redirects.
		 *
		 * @return array
		 */
		private static function redirect_paths() {
			$paths = array(
				'/home/'         => '/',
				'/newsletter-2/' => '/newsletter/',
			);
			$paths = apply_filters( 'aiamigos_remediation_redirect_paths', $paths );
			return is_array( $paths ) ? $paths : array();
		}

		/**
		 * Exact public demo paths that must return 410.
		 *
		 * @return array
		 */
		private static function gone_paths() {
			$paths = array(
				'/classes/recent-case-title-01/',
				'/classes/recent-case-title-02/',
				'/testimonials/client-name-01/',
				'/testimonials/client-name-02/',
				'/testimonials/client-name-03/',
				'/team/member-name-02/',
				'/team/member-name-03/',
				'/team/member-name-04/',
			);
			$paths = apply_filters( 'aiamigos_remediation_gone_paths', $paths );
			return is_array( $paths ) ? $paths : array();
		}

		/**
		 * Seeded theme-demo records retained only for recoverable admin access.
		 *
		 * ID 38 is the genuine Vijay team record and is deliberately absent.
		 *
		 * @return array
		 */
		private static function quarantined_post_ids() {
			$ids = array( 34, 36, 46, 48, 50, 40, 42, 44 );
			$ids = apply_filters( 'aiamigos_remediation_quarantined_post_ids', $ids );
			return AIAmigos_Remediation_Policy::merge_positive_ids( array(), is_array( $ids ) ? $ids : array() );
		}

		/**
		 * Published factual records that must never appear in a sitemap while noindex.
		 *
		 * @return array
		 */
		private static function high_risk_post_ids() {
			$ids = array( 945, 441, 783, 1405 );
			$ids = apply_filters( 'aiamigos_remediation_high_risk_post_ids', $ids );
			return AIAmigos_Remediation_Policy::merge_positive_ids( array(), is_array( $ids ) ? $ids : array() );
		}

		/**
		 * All records suppressed from XML sitemaps.
		 *
		 * @return array
		 */
		private static function sitemap_excluded_post_ids() {
			return AIAmigos_Remediation_Policy::merge_positive_ids( self::quarantined_post_ids(), self::high_risk_post_ids() );
		}

		/**
		 * Keep seeded demo records out of every non-admin front-end WP_Query.
		 *
		 * @param WP_Query $query Query about to run.
		 * @return void
		 */
		public static function exclude_quarantined_records_from_queries( $query ) {
			if ( ! self::is_frontend_request() || ! is_object( $query ) || ! method_exists( $query, 'get' ) || ! method_exists( $query, 'set' ) ) {
				return;
			}
			if ( method_exists( $query, 'is_feed' ) && $query->is_feed() ) {
				return;
			}
			$post_types           = (array) $query->get( 'post_type' );
			$infrastructure_types = array( 'attachment', 'revision', 'nav_menu_item', 'wpcf7_contact_form' );
			if ( array_intersect( $post_types, $infrastructure_types ) ) {
				return;
			}

			$quarantined = self::quarantined_post_ids();
			$post_in     = $query->get( 'post__in' );
			if ( is_array( $post_in ) && ! empty( $post_in ) ) {
				$allowed = array_values( array_diff( AIAmigos_Remediation_Policy::merge_positive_ids( array(), $post_in ), $quarantined ) );
				// WP_Query treats an empty post__in as unrestricted, so force an
				// impossible ID when the original allowlist contained only demo IDs.
				$query->set( 'post__in', empty( $allowed ) ? array( 0 ) : $allowed );
				return;
			}

			$existing = $query->get( 'post__not_in' );
			$query->set( 'post__not_in', AIAmigos_Remediation_Policy::merge_positive_ids( $existing, $quarantined ) );
		}

		/**
		 * Remove seeded demo records from Rank Math XML sitemap output.
		 *
		 * @param array|false $url    Sitemap URL entry.
		 * @param string      $type   Entry type: post, term, or user.
		 * @param object      $object Source object.
		 * @return array|false
		 */
		public static function filter_rank_math_sitemap_entry( $url, $type, $object ) {
			$post_id = ( 'post' === $type && is_object( $object ) && isset( $object->ID ) ) ? (int) $object->ID : 0;
			return $post_id && in_array( $post_id, self::sitemap_excluded_post_ids(), true ) ? false : $url;
		}

		/**
		 * Apply the same quarantine to WordPress core post sitemaps.
		 *
		 * @param array  $args      WP_Query arguments.
		 * @param string $post_type Post type being indexed.
		 * @return array
		 */
		public static function filter_core_sitemap_query_args( $args, $post_type ) {
			if ( ! is_array( $args ) ) {
				$args = array();
			}
			$existing             = isset( $args['post__not_in'] ) ? $args['post__not_in'] : array();
			$args['post__not_in'] = AIAmigos_Remediation_Policy::merge_positive_ids( $existing, self::sitemap_excluded_post_ids() );
			return $args;
		}

		/**
		 * Apply the same exact exclusions to Yoast post sitemaps when installed.
		 *
		 * @param array $post_ids Existing excluded IDs.
		 * @return array
		 */
		public static function filter_yoast_sitemap_post_ids( $post_ids ) {
			return AIAmigos_Remediation_Policy::merge_positive_ids( $post_ids, self::sitemap_excluded_post_ids() );
		}

		/**
		 * Exact factual pages that remain published but are temporarily noindex.
		 *
		 * @return array
		 */
		private static function high_risk_noindex_paths() {
			$paths = array(
				'/ai-certifications/',
				'/gpt-models/',
				'/grokai/',
				'/ai-model-benchmarks-a-comprehensive-guide/',
			);
			$paths = apply_filters( 'aiamigos_remediation_high_risk_noindex_paths', $paths );
			return is_array( $paths ) ? $paths : array();
		}

		/**
		 * Whether the current native request is the canonical blog route.
		 *
		 * @return bool
		 */
		private static function is_blog_archive_request() {
			if ( ! is_home() ) {
				return false;
			}
			$path = AIAmigos_Remediation_Policy::normalize_path( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/' );
			$blog = preg_quote( trim( self::blog_base_path(), '/' ), '#' );
			return (bool) preg_match( '#^/' . $blog . '(?:/page/(?:[2-9]|[1-9][0-9]+))?/$#i', $path );
		}

		/**
		 * Give canonical archive pages differentiated browser titles.
		 *
		 * @param array $parts Document-title parts.
		 * @return array
		 */
		public static function filter_blog_document_title( $parts ) {
			if ( self::is_blog_archive_request() ) {
				$paged          = max( 1, (int) get_query_var( 'paged' ) );
				$parts['title'] = 1 < $paged ? sprintf( __( 'AI Amigos Blog - Page %d', 'aiamigos-remediation' ), $paged ) : __( 'AI Amigos Blog', 'aiamigos-remediation' );
			}
			return $parts;
		}

		/**
		 * Give Rank Math and Yoast the same differentiated native blog title.
		 *
		 * @param string $title Existing SEO title.
		 * @return string
		 */
		public static function filter_blog_seo_title( $title ) {
			if ( ! self::is_blog_archive_request() ) {
				return $title;
			}
			$paged = max( 1, (int) get_query_var( 'paged' ) );
			return 1 < $paged ? sprintf( __( 'AI Amigos Blog - Page %d', 'aiamigos-remediation' ), $paged ) : __( 'AI Amigos Blog', 'aiamigos-remediation' );
		}

		/**
		 * Canonical URL for supported SEO plugins on /blog/ pages.
		 *
		 * @param string $canonical Existing canonical.
		 * @return string
		 */
		public static function filter_blog_canonical( $canonical ) {
			if ( ! self::is_blog_archive_request() ) {
				return $canonical;
			}
			$paged = max( 1, (int) get_query_var( 'paged' ) );
			$path  = self::blog_base_path();
			if ( 1 < $paged ) {
				$path .= 'page/' . $paged . '/';
			}
			return self::canonical_url_for_path( $path );
		}

		/**
		 * Apply 410 and redirect policy before theme rendering.
		 *
		 * @return void
		 */
		public static function apply_route_policy() {
			if ( ! self::is_frontend_request() ) {
				return;
			}

			$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
			$path        = AIAmigos_Remediation_Policy::normalize_path( $request_uri );
			if ( AIAmigos_Remediation_Policy::path_is_listed( $path, self::gone_paths() ) ) {
				self::render_gone_response();
			}

			$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
			if ( ! in_array( $method, array( 'GET', 'HEAD' ), true ) ) {
				return;
			}

			$target_path = AIAmigos_Remediation_Policy::redirect_target_path( $path, self::redirect_paths(), self::blog_base_path() );
			if ( null === $target_path ) {
				return;
			}

			$destination = self::canonical_url_for_path( $target_path );
			if ( apply_filters( 'aiamigos_remediation_preserve_redirect_query', true, $path, $target_path ) ) {
				$query = parse_url( (string) $request_uri, PHP_URL_QUERY );
				if ( is_string( $query ) && '' !== $query ) {
					$destination .= '?' . str_replace( array( "\r", "\n" ), '', $query );
				}
			}

			$status = (int) apply_filters( 'aiamigos_remediation_redirect_status', 301, $path, $target_path );
			if ( ! in_array( $status, array( 301, 308 ), true ) ) {
				$status = 301;
			}
			if ( wp_safe_redirect( $destination, $status, 'AI Amigos Remediation' ) ) {
				exit;
			}
		}

		/**
		 * Build a canonical URL from a normalized site path.
		 *
		 * @param string $path Site path.
		 * @return string
		 */
		private static function canonical_url_for_path( $path ) {
			return rtrim( self::canonical_base_url(), '/' ) . AIAmigos_Remediation_Policy::normalize_path( $path );
		}

		/**
		 * Allow wp_safe_redirect to use the configured canonical www host.
		 *
		 * @param array $hosts Allowed hosts.
		 * @return array
		 */
		public static function allow_canonical_redirect_host( $hosts ) {
			$host = wp_parse_url( self::canonical_base_url(), PHP_URL_HOST );
			if ( $host ) {
				$hosts[] = $host;
			}
			return array_values( array_unique( $hosts ) );
		}

		/**
		 * Emit an explicit, uncached 410 without buffering the document.
		 *
		 * @return void
		 */
		private static function render_gone_response() {
			status_header( 410 );
			nocache_headers();
			header( 'X-Robots-Tag: noindex, nofollow', true );

			$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
			if ( 'HEAD' === $method ) {
				exit;
			}

			$template = locate_template( array( '410.php' ), false, false );
			if ( $template ) {
				include $template;
				exit;
			}

			wp_die(
				esc_html__( 'This demonstration record has been permanently removed.', 'aiamigos-remediation' ),
				esc_html__( 'Content removed', 'aiamigos-remediation' ),
				array( 'response' => 410 )
			);
		}

		/**
		 * Determine noindex status for exact high-risk pages and archive surfaces.
		 *
		 * @return bool
		 */
		private static function should_noindex() {
			if ( ! self::is_frontend_request() ) {
				return false;
			}
			$path = AIAmigos_Remediation_Policy::normalize_path( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/' );
			if ( AIAmigos_Remediation_Policy::path_is_listed( $path, self::high_risk_noindex_paths() ) ) {
				return (bool) apply_filters( 'aiamigos_remediation_should_noindex', true, $path, 'high-risk-path' );
			}
			if ( self::is_blog_archive_request() ) {
				return false;
			}

			$is_archive_surface = is_author() || is_category() || is_tag() || is_tax() || is_date() || is_search() || is_post_type_archive();
			$is_archive_surface = (bool) apply_filters( 'aiamigos_remediation_noindex_archive_surfaces', $is_archive_surface, $path );
			return (bool) apply_filters( 'aiamigos_remediation_should_noindex', $is_archive_surface, $path, 'archive-surface' );
		}

		/**
		 * Add core robots directives.
		 *
		 * @param array $robots Robots directives.
		 * @return array
		 */
		public static function filter_wp_robots( $robots ) {
			if ( self::should_noindex() ) {
				unset( $robots['index'], $robots['nofollow'] );
				$robots['noindex'] = true;
				$robots['follow']  = true;
			}
			return $robots;
		}

		/**
		 * Add noindex to Rank Math's array or string contract.
		 *
		 * @param mixed $robots Rank Math directives.
		 * @return mixed
		 */
		public static function filter_rank_math_robots( $robots ) {
			if ( ! self::should_noindex() ) {
				return $robots;
			}
			if ( is_array( $robots ) ) {
				unset( $robots['index'], $robots['nofollow'] );
				$robots['noindex'] = 'noindex';
				$robots['follow'] = 'follow';
				return $robots;
			}
			return self::force_noindex_string( $robots );
		}

		/**
		 * Add noindex to string-based SEO plugin contracts.
		 *
		 * @param string $robots Robots string.
		 * @return string
		 */
		public static function filter_robots_string( $robots ) {
			return self::should_noindex() ? self::force_noindex_string( $robots ) : $robots;
		}

		/**
		 * Normalize a robots string to noindex,follow without destructive nofollow.
		 *
		 * @param mixed $robots Existing value.
		 * @return string
		 */
		private static function force_noindex_string( $robots ) {
			$directives = preg_split( '/\s*,\s*/', strtolower( (string) $robots ), -1, PREG_SPLIT_NO_EMPTY );
			$directives = array_diff( $directives, array( 'index', 'noindex', 'follow', 'nofollow' ) );
			array_unshift( $directives, 'noindex', 'follow' );
			return implode( ', ', array_values( array_unique( $directives ) ) );
		}

		/**
		 * Add conservative front-end headers and a redundant X-Robots-Tag.
		 *
		 * @param array $headers Response headers.
		 * @return array
		 */
		public static function filter_response_headers( $headers ) {
			if ( ! self::is_frontend_request() ) {
				return $headers;
			}
			$secure = is_ssl() || ( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && 'https' === strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) ) ) );
			$policy = array(
				'X-Content-Type-Options' => 'nosniff',
				'X-Frame-Options'        => 'SAMEORIGIN',
				'Referrer-Policy'        => 'strict-origin-when-cross-origin',
				'Permissions-Policy'     => 'camera=(), microphone=(), geolocation=(), payment=(), usb=()',
			);
			if ( $secure ) {
				$policy['Strict-Transport-Security'] = 'max-age=15552000';
			}
			$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
			$cacheable = ! is_user_logged_in() && ! is_preview() && ! is_404() && ! is_search() && ! is_feed() && ! post_password_required();
			if ( $cacheable && in_array( $method, array( 'GET', 'HEAD' ), true ) && empty( $headers['Cache-Control'] ) ) {
				$headers['Cache-Control'] = 'public, max-age=300, stale-while-revalidate=30';
			}
			$policy = apply_filters( 'aiamigos_remediation_security_headers', $policy );
			if ( is_array( $policy ) ) {
				foreach ( $policy as $name => $value ) {
					if ( is_string( $name ) && preg_match( '/^[A-Za-z0-9-]+$/', $name ) && is_scalar( $value ) ) {
						$headers[ $name ] = str_replace( array( "\r", "\n" ), '', (string) $value );
					}
				}
			}
			// wp_headers can run before the main query is populated. Exact paths are
			// safe here; archive surfaces receive their meta robots directive later.
			$path = AIAmigos_Remediation_Policy::normalize_path( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/' );
			if ( AIAmigos_Remediation_Policy::path_is_listed( $path, self::high_risk_noindex_paths() ) ) {
				$headers['X-Robots-Tag'] = 'noindex, follow';
			}
			return $headers;
		}

		/**
		 * Remove the PHP version disclosure when the hosting layer permits it.
		 *
		 * @return void
		 */
		public static function remove_runtime_disclosure_header() {
			if ( self::is_frontend_request() && function_exists( 'header_remove' ) ) {
				header_remove( 'X-Powered-By' );
			}
		}

		/**
		 * Normalize same-site nav menu links only; external links are untouched.
		 *
		 * @param array   $atts  Link attributes.
		 * @param WP_Post $item  Menu item.
		 * @param stdClass $args Menu arguments.
		 * @param int     $depth Menu depth.
		 * @return array
		 */
		public static function normalize_menu_link( $atts, $item, $args, $depth ) {
			if ( self::is_frontend_request() && ! empty( $atts['href'] ) ) {
				$atts['href'] = AIAmigos_Remediation_Policy::normalize_menu_url( $atts['href'], self::canonical_base_url(), self::redirect_paths(), self::blog_base_path() );
			}
			return $atts;
		}

		/**
		 * Remove async/defer only from exact WordPress dependency handles.
		 *
		 * @param string $tag    Script tag.
		 * @param string $handle Script handle.
		 * @param string $src    Script URL.
		 * @return string
		 */
		public static function make_wp_dependencies_blocking( $tag, $handle, $src ) {
			$handles = apply_filters( 'aiamigos_remediation_blocking_wp_dependency_handles', array( 'wp-hooks', 'wp-i18n' ) );
			if ( is_array( $handles ) && in_array( $handle, $handles, true ) ) {
				return AIAmigos_Remediation_Policy::strip_script_loading_strategy( $tag );
			}
			return $tag;
		}

		/**
		 * Replace broken MailPoet IDs 2/3 with an honestly labelled CF7 request.
		 *
		 * @param string $content Widget or page content.
		 * @return string
		 */
		public static function replace_mailpoet_form( $content ) {
			if ( ! self::is_frontend_request() || false === stripos( (string) $content, '[mailpoet_form' ) ) {
				return $content;
			}
			$form_ids = apply_filters( 'aiamigos_remediation_mailpoet_form_ids', array( 2, 3 ) );
			$form_ids = is_array( $form_ids ) ? array_map( 'absint', $form_ids ) : array( 2, 3 );
			return AIAmigos_Remediation_Policy::replace_mailpoet_forms( $content, self::update_request_markup(), $form_ids );
		}

		/**
		 * Replace only the misleading title attached to the affected text widget.
		 *
		 * @param string $title    Widget title.
		 * @param array  $instance Widget instance.
		 * @param string $id_base  Widget base ID.
		 * @return string
		 */
		public static function label_update_request_widget( $title, $instance, $id_base ) {
			$text = is_array( $instance ) && isset( $instance['text'] ) ? (string) $instance['text'] : '';
			if ( self::is_frontend_request() && false !== stripos( $text, '[mailpoet_form' ) ) {
				// The replacement section carries its own accessible label. Returning
				// an empty title avoids the theme's sitewide H3 hierarchy defect.
				return '';
			}
			return $title;
		}

		/**
		 * Build request markup without claiming an automatic newsletter signup.
		 *
		 * @return string
		 */
		private static function update_request_markup() {
			$form       = '';
			$form_title = trim( (string) apply_filters( 'aiamigos_remediation_cf7_form_title', 'Subscribe Newsletter Form' ) );
			$intro      = esc_html__( 'Send a request to receive information about future AI Amigos updates. This is a contact request, not an automatic newsletter subscription.', 'aiamigos-remediation' );

			if ( '' !== $form_title && class_exists( 'WPCF7_ContactForm' ) && is_callable( array( 'WPCF7_ContactForm', 'find' ) ) && shortcode_exists( 'contact-form-7' ) ) {
				$forms = WPCF7_ContactForm::find(
					array(
						'title'          => $form_title,
						'post_status'    => 'publish',
						'posts_per_page' => 2,
					)
				);
				$exact = array();
				if ( is_array( $forms ) ) {
					foreach ( $forms as $candidate ) {
						if ( is_object( $candidate ) && is_callable( array( $candidate, 'title' ) ) && $form_title === trim( (string) $candidate->title() ) ) {
							$exact[] = $candidate;
						}
					}
				}
				if ( 1 === count( $exact ) && is_callable( array( $exact[0], 'shortcode' ) ) ) {
					$shortcode = (string) $exact[0]->shortcode();
					if ( '' !== trim( $shortcode ) ) {
						$form = (string) do_shortcode( $shortcode );
					}
				}
			}

			if ( '' === trim( $form ) ) {
				$email = sanitize_email( (string) apply_filters( 'aiamigos_remediation_contact_email', 'contact@aiamigos.org' ) );
				if ( ! is_email( $email ) ) {
					$email = 'contact@aiamigos.org';
				}
				$form = sprintf(
					'<p><a href="%s">%s</a></p>',
					esc_url( 'mailto:' . $email ),
					sprintf( esc_html__( 'Email %s to request updates.', 'aiamigos-remediation' ), esc_html( $email ) )
				);
			}
			return sprintf(
				'<section class="aiamigos-update-request" aria-label="%1$s"><p class="aiamigos-update-request__label">%1$s</p><p>%2$s</p>%3$s</section>',
				esc_attr__( 'AI Amigos update request', 'aiamigos-remediation' ),
				$intro,
				$form
			);
		}

		/**
		 * Render one factual author/date line on standard single posts.
		 *
		 * @param string $content Post content.
		 * @return string
		 */
		public static function prepend_accountable_byline( $content ) {
			if ( ! self::is_frontend_request() || is_feed() || ! is_singular( 'post' ) || ! is_main_query() || ! in_the_loop() ) {
				return $content;
			}
			$post_id = get_the_ID();
			if ( ! $post_id || isset( self::$byline_rendered[ $post_id ] ) ) {
				return $content;
			}
			self::$byline_rendered[ $post_id ] = true;

			$author_id   = (int) get_post_field( 'post_author', $post_id );
			$author_name = trim( (string) get_the_author_meta( 'display_name', $author_id ) );
			if ( '' === $author_name ) {
				return $content;
			}
			$published_timestamp = (int) get_post_time( 'U', true, $post_id );
			$modified_timestamp  = (int) get_post_modified_time( 'U', true, $post_id );
			$published_iso       = get_post_time( DATE_W3C, true, $post_id );
			$modified_iso        = get_post_modified_time( DATE_W3C, true, $post_id );
			$published_display   = get_the_date( get_option( 'date_format' ), $post_id );
			$modified_display    = get_the_modified_date( get_option( 'date_format' ), $post_id );
			$author_url          = get_author_posts_url( $author_id );

			$byline = sprintf(
				'<p class="aiamigos-accountable-byline"><span>%1$s <a rel="author" href="%2$s">%3$s</a></span><span>%4$s <time datetime="%5$s">%6$s</time></span>',
				esc_html__( 'By', 'aiamigos-remediation' ),
				esc_url( $author_url ),
				esc_html( $author_name ),
				esc_html__( 'Published', 'aiamigos-remediation' ),
				esc_attr( $published_iso ),
				esc_html( $published_display )
			);
			if ( $modified_timestamp >= $published_timestamp + DAY_IN_SECONDS ) {
				$byline .= sprintf(
					'<span>%1$s <time datetime="%2$s">%3$s</time></span>',
					esc_html__( 'Updated', 'aiamigos-remediation' ),
					esc_attr( $modified_iso ),
					esc_html( $modified_display )
				);
			}
			$byline .= '</p>';
			return $byline . $content;
		}

		/**
		 * Correct Sirat's widget-title hierarchy without changing widget data.
		 *
		 * @param array $params Dynamic-sidebar parameters.
		 * @return array
		 */
		public static function normalize_widget_heading_level( $params ) {
			if ( ! self::is_frontend_request() || ! is_array( $params ) || empty( $params[0] ) || ! is_array( $params[0] ) ) {
				return $params;
			}
			if ( isset( $params[0]['before_title'] ) ) {
				$params[0]['before_title'] = preg_replace( '/<h3\b/i', '<h2', (string) $params[0]['before_title'], 1 );
			}
			if ( isset( $params[0]['after_title'] ) ) {
				$params[0]['after_title'] = preg_replace( '#</h3>#i', '</h2>', (string) $params[0]['after_title'], 1 );
			}
			return $params;
		}

		/**
		 * Read an unfiltered theme mod so phone/email migration has no recursion.
		 *
		 * @param string $name Theme mod name.
		 * @return mixed|null
		 */
		private static function raw_theme_mod( $name ) {
			$stylesheet = get_option( 'stylesheet' );
			$mods       = $stylesheet ? get_option( 'theme_mods_' . $stylesheet, array() ) : array();
			return is_array( $mods ) && array_key_exists( $name, $mods ) ? $mods[ $name ] : null;
		}

		/**
		 * Suppress email-like data from the theme's tel: field; preserve phones.
		 *
		 * @param mixed $value Theme mod value.
		 * @return mixed
		 */
		public static function filter_theme_phone_mod( $value ) {
			if ( self::is_frontend_request() && AIAmigos_Remediation_Policy::is_email_like( $value ) ) {
				return '';
			}
			return $value;
		}

		/**
		 * Recover the valid misplaced email only when the email field is empty.
		 *
		 * @param mixed $value Dedicated email mod.
		 * @return mixed
		 */
		public static function filter_theme_email_mod( $value ) {
			if ( ! self::is_frontend_request() || '' !== trim( (string) $value ) ) {
				return $value;
			}
			$misplaced = self::raw_theme_mod( 'vw_sirat_pro_header_section_call2' );
			return AIAmigos_Remediation_Policy::is_email_like( $misplaced ) ? sanitize_email( $misplaced ) : $value;
		}

		/**
		 * Dynamic footer notice; the stored Customizer value is untouched.
		 *
		 * @param mixed $value Existing footer text.
		 * @return mixed
		 */
		public static function filter_footer_copy_mod( $value ) {
			if ( ! self::is_frontend_request() ) {
				return $value;
			}
			$year = function_exists( 'wp_date' ) ? wp_date( 'Y' ) : gmdate( 'Y' );
			$copy = sprintf( '© %s AI Amigos.', $year );
			return apply_filters( 'aiamigos_remediation_footer_copy', $copy, $year );
		}

		/**
		 * Hide the misleading theme credit on the public front end.
		 *
		 * @param mixed $value Existing setting.
		 * @return mixed
		 */
		public static function hide_theme_credit_mod( $value ) {
			return self::is_frontend_request() ? false : $value;
		}

		/**
		 * Register small component styles without editing or buffering templates.
		 *
		 * @return void
		 */
		public static function enqueue_inline_styles() {
			if ( ! self::is_frontend_request() ) {
				return;
			}
			wp_register_style( 'aiamigos-remediation', false, array(), AIAMIGOS_REMEDIATION_VERSION );
			wp_enqueue_style( 'aiamigos-remediation' );
			wp_add_inline_style(
				'aiamigos-remediation',
				'.aiamigos-remediation-intro,.aiamigos-remediation-blog-heading{max-width:1140px;margin:1.5rem auto;padding:0 1rem}.aiamigos-remediation-intro h1,.aiamigos-remediation-blog-heading{overflow-wrap:anywhere}.aiamigos-update-request__label{font-weight:700}.aiamigos-update-request{max-width:42rem}.aiamigos-accountable-byline{display:flex;flex-wrap:wrap;gap:.35rem 1rem;margin:0 0 1.25rem;font-size:.95rem}'
			);
		}

		/**
		 * Add the requested cautious front-page H1 after the theme slider.
		 *
		 * @return void
		 */
		public static function render_front_page_intro() {
			if ( self::$front_intro_rendered || ! self::is_frontend_request() || ! is_front_page() || is_paged() ) {
				return;
			}
			self::$front_intro_rendered = true;
			$title = __( 'AI Amigos: practical artificial intelligence guides', 'aiamigos-remediation' );
			$text  = __( 'Explore plain-language articles about AI concepts, tools, learning paths, and responsible use. Check each article’s publication date and cited sources before relying on fast-changing information.', 'aiamigos-remediation' );
			echo '<section class="aiamigos-remediation-intro" aria-labelledby="aiamigos-remediation-intro-title"><h1 id="aiamigos-remediation-intro-title">' . esc_html( $title ) . '</h1><p>' . esc_html( $text ) . '</p></section>';
		}

		/**
		 * Add one visible H1 immediately before the canonical posts loop.
		 *
		 * @param WP_Query $query Loop query.
		 * @return void
		 */
		public static function render_blog_archive_heading( $query ) {
			if ( self::$blog_heading_rendered || ! self::is_frontend_request() || ! is_home() || ! self::is_blog_archive_request() || ! $query->is_main_query() ) {
				return;
			}
			self::$blog_heading_rendered = true;
			echo '<h1 class="aiamigos-remediation-blog-heading">' . esc_html__( 'AI Amigos Blog', 'aiamigos-remediation' ) . '</h1>';
		}

		/**
		 * Detect archive/listing contexts for image policy.
		 *
		 * @return bool
		 */
		private static function is_listing_context() {
			return self::is_frontend_request() && ( is_home() || is_archive() || is_search() || self::is_blog_archive_request() );
		}

		/**
		 * Prevent listing cards from requesting original/full featured images.
		 *
		 * @param string|array $size    Requested size.
		 * @param int          $post_id Post ID.
		 * @return string|array
		 */
		public static function filter_listing_thumbnail_size( $size, $post_id ) {
			if ( self::is_listing_context() ) {
				return apply_filters( 'aiamigos_remediation_listing_thumbnail_size', 'large', $post_id, $size );
			}
			return $size;
		}

	}
}
