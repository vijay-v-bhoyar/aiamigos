#!/usr/bin/env node
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

async function phpFiles(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(entries.map(async (entry) => {
    const target = path.join(directory, entry.name);
    if (entry.isDirectory()) return phpFiles(target);
    return entry.isFile() && entry.name.endsWith(".php") ? [target] : [];
  }));
  return nested.flat();
}

function structuralBalance(source) {
  const counts = { "{": 0, "(": 0, "[": 0 };
  const close = { "}": "{", ")": "(", "]": "[" };
  let state = "code";
  let escaped = false;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    const next = source[index + 1];
    if (state === "line") {
      if (char === "\n") state = "code";
      continue;
    }
    if (state === "block") {
      if (char === "*" && next === "/") { state = "code"; index += 1; }
      continue;
    }
    if (state === "single" || state === "double") {
      if (escaped) { escaped = false; continue; }
      if (char === "\\") { escaped = true; continue; }
      if ((state === "single" && char === "'") || (state === "double" && char === '"')) state = "code";
      continue;
    }
    if (char === "/" && next === "/") { state = "line"; index += 1; continue; }
    if (char === "#") { state = "line"; continue; }
    if (char === "/" && next === "*") { state = "block"; index += 1; continue; }
    if (char === "'") { state = "single"; continue; }
    if (char === '"') { state = "double"; continue; }
    if (Object.hasOwn(counts, char)) counts[char] += 1;
    if (Object.hasOwn(close, char)) counts[close[char]] -= 1;
    if (Object.values(counts).some((value) => value < 0)) return false;
  }
  return state === "code" && Object.values(counts).every((value) => value === 0);
}

const files = await phpFiles(root);
const sources = Object.fromEntries(await Promise.all(files.map(async (file) => [file, await readFile(file, "utf8")])));
const all = Object.values(sources).join("\n");
const pluginFile = path.join(root, "includes", "class-aiamigos-remediation-plugin.php");
const policyFile = path.join(root, "includes", "class-aiamigos-remediation-policy.php");
const bootstrapFile = path.join(root, "aiamigos-remediation.php");
const plugin = sources[pluginFile];
const policy = sources[policyFile];
const bootstrap = sources[bootstrapFile];
let failures = 0;
let checks = 0;

function check(condition, label) {
  checks += 1;
  if (condition) console.log(`PASS ${label}`);
  else { failures += 1; console.error(`FAIL ${label}`); }
}

for (const [file, source] of Object.entries(sources)) check(structuralBalance(source), `balanced PHP structure: ${path.relative(root, file)}`);
check(/Version:\s*1\.1\.0/.test(bootstrap) && /AIAMIGOS_REMEDIATION_VERSION',\s*'1\.1\.0'/.test(bootstrap), "plugin versions agree");
check(!/[ÂÃ]|â(?:€™|€|†|‡|ˆ|œ|ž)/u.test(all), "no common UTF-8 mojibake markers");
check(!/\$attr\s*\[\s*['"]loading['"]\s*\]\s*=\s*['"]lazy['"]/.test(plugin), "plugin does not force lazy loading");
check(!/unset\s*\(\s*\$attr\s*\[\s*['"]fetchpriority['"]/.test(plugin), "plugin preserves core fetch priority");
check(/post__in/.test(plugin) && /array\(\s*0\s*\)/.test(plugin), "explicit allowlists fail closed after quarantine subtraction");
check(/wpseo_exclude_from_sitemap_by_post_ids/.test(plugin) && /wp_sitemaps_posts_query_args/.test(plugin) && /rank_math\/sitemap\/entry/.test(plugin), "all supported sitemap exclusions are registered");
check(/945,\s*441,\s*783,\s*1405/.test(plugin), "factual-risk record IDs are sitemap-excluded");
check(/RankMath\\Sitemap\\Cache/.test(plugin) && /invalidate_storage/.test(plugin), "activation invalidates Rank Math sitemap storage when available");
check(/unset\(\s*\$robots\['index'\],\s*\$robots\['nofollow'\]\s*\)/.test(plugin) && /\$robots\['noindex'\]\s*=\s*'noindex'/.test(plugin), "Rank Math robots array uses noindex key");
check(/post_status'\s*=>\s*'publish'/.test(plugin) && /posts_per_page'\s*=>\s*2/.test(plugin) && /1\s*===\s*count\(\s*\$exact\s*\)/.test(plugin), "CF7 selection rejects unpublished or ambiguous matches");
check(/add_filter\(\s*'the_content'.*'prepend_accountable_byline'\s*\),\s*9\s*\)/s.test(plugin), "accountable byline runs after shortcode replacement");
check(/is_singular\(\s*'post'\s*\)/.test(plugin) && /is_main_query\(\)/.test(plugin) && /in_the_loop\(\)/.test(plugin), "byline is limited to the main standard-post loop");
check(/DAY_IN_SECONDS/.test(plugin) && /get_post_modified_time/.test(plugin), "updated date requires a material timestamp difference");
check(/X-Frame-Options'\s*=>\s*'SAMEORIGIN'/.test(plugin) && /Cache-Control/.test(plugin), "frame and cache header policies are present");
check(/header_remove\(\s*'X-Powered-By'\s*\)/.test(plugin), "runtime disclosure removal is attempted");
check(/return\s+\$target_path\s*===\s*\$path\s*\?\s*null/.test(policy), "self redirects are suppressed");
check(/\[1-9\]\[0-9\]\+/.test(policy), "legacy pagination includes pages 10 and above");
check(/wp_safe_redirect[\s\S]*?\)\s*\{\s*exit;/m.test(plugin), "redirect exits only after a successful send");

const callbackMatches = [...plugin.matchAll(/add_(?:action|filter)\([^;]*?array\(\s*__CLASS__,\s*'([^']+)'\s*\)/gs)].map((match) => match[1]);
const methodNames = new Set([...plugin.matchAll(/function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(/g)].map((match) => match[1]));
const missingCallbacks = [...new Set(callbackMatches)].filter((name) => !methodNames.has(name));
check(missingCallbacks.length === 0, `all ${new Set(callbackMatches).size} registered class callbacks resolve${missingCallbacks.length ? `: ${missingCallbacks.join(", ")}` : ""}`);

console.log(`\n${checks} check(s), ${failures} failure(s).`);
process.exitCode = failures ? 1 : 0;
